#include <iostream>

using namespace std;

int main()
{
    int array1[2][2]={1,2,3,4};
    int array2[2][2]={5,6,7,8};
    int array3[2][2]={9,10,11,12};
    int array4[2][2]={13,14,15,16};
    int array5[2][2];

    for(int i=0;i<2;i++){
        for(int j=0;j<2;j++){
            array5[i][j]=array1[i][j]+array2[i][j]+array3[i][j]+array4[i][j];
        }
    }

    cout<<"The Addition Of 4 Matrices: "<<endl;
    for(int i=0;i<2;i++){
        for(int j=0;j<2;j++){
            cout<<array5[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}
