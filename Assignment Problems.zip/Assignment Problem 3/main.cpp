#include<iostream>

using namespace std;

void zero_small(int &a, int &b) {
    if(a < b) {
        a = 0;
    } else {
        b = 0;
    }
}

int main() {
    int num1, num2;

    cout << "Enter first number: ";
    cin >> num1;

    cout << "Enter second number: ";
    cin >> num2;

    cout << "Before function call, " << endl;
    cout << "Number 1: " << num1 << endl;
    cout << "Number 2: " << num2 << endl;

    zero_small(num1, num2);

    cout << "After function call, " << endl;
    cout << "Number 1: " << num1 << endl;
    cout << "Number 2: " << num2 << endl;

    return 0;
}
