#include<iostream>
using namespace std;

struct Student {
    int id;
    int credits;
    double cgpa;
};

int main() {
    Student students[5];

    for(int i = 0; i < 5; i++) {
        cout << "Enter Student " << i + 1 << " Information:" << endl;
        cout << "ID: ";
        cin >> students[i].id;
        cout << "Credits: ";
        cin >> students[i].credits;
        cout << "CGPA: ";
        cin >> students[i].cgpa;
    }

    cout << "Students With More Than 60 Credits:" << endl;
    bool flag=false;
    for(int i=0;i<5;i++) {
        if(students[i].credits>60) {
            cout<<"ID: "<<students[i].id<<endl;
            flag=true;
        }
    }
    if(!flag) {
        cout<<"No Student Found"<<endl;
    }

    cout << "Students with CGPA more than 3.60: " << endl;
    for(int i = 0; i < 5; i++) {
        if(students[i].cgpa > 3.60) {
            cout << "ID: " << students[i].id << endl;
        } else{
            cout<<"No Student Found"<<endl;
        }
    }

    return 0;
}
