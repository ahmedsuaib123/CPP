#include<iostream>

using namespace std;

struct Complex {
    double real;
    double imag;
};

Complex addComplex(Complex c1, Complex c2) {
    Complex temp;
    temp.real = c1.real + c2.real;
    temp.imag = c1.imag + c2.imag;
    return temp;
}

Complex subtractComplex(Complex c1, Complex c2) {
    Complex temp;
    temp.real = c1.real - c2.real;
    temp.imag = c1.imag - c2.imag;
    return temp;
}

Complex multiplyComplex(Complex c1, Complex c2) {
    Complex temp;
    temp.real = c1.real * c2.real - c1.imag * c2.imag;
    temp.imag = c1.real * c2.imag + c1.imag * c2.real;
    return temp;
}

Complex divideComplex(Complex c1, Complex c2) {
    Complex temp;
    double denominator = c2.real * c2.real + c2.imag * c2.imag;
    temp.real = (c1.real * c2.real + c1.imag * c2.imag) / denominator;
    temp.imag = (c1.imag * c2.real - c1.real * c2.imag) / denominator;
    return temp;
}

void displayComplex(Complex c) {
    cout << c.real << " + " << c.imag << "i" << endl;
}

int main() {
    Complex c1, c2, result;

    cout << "Enter real and imaginary parts of first complex number: ";
    cin >> c1.real >> c1.imag;

    cout << "Enter real and imaginary parts of second complex number: ";
    cin >> c2.real >> c2.imag;

    cout << "Complex number 1: ";
    displayComplex(c1);

    cout << "Complex number 2: ";
    displayComplex(c2);

    result = addComplex(c1, c2);
    cout << "Addition: ";
    displayComplex(result);

    result = subtractComplex(c1, c2);
    cout << "Subtraction: ";
    displayComplex(result);

    result = multiplyComplex(c1, c2);
    cout << "Multiplication: ";
    displayComplex(result);

    result = divideComplex(c1, c2);
    cout << "Division: ";
    displayComplex(result);

    return 0;
}
